import tkinter as tk
from tkinter import ttk, messagebox, simpledialog
from datetime import datetime, timedelta
import pandas as pd

class TaskManagerGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("Advanced Task Manager with Subtasks")

        self.tree = ttk.Treeview(root, columns=('Task Title', 'Start Time', 'Subtask Description', 'Duration'), show='headings', height=15)
        self.tree.grid(row=0, column=0, columnspan=4, sticky='nsew')
        self.tree.heading('Task Title', text='Task Title')
        self.tree.heading('Start Time', text='Start Time')
        self.tree.heading('Subtask Description', text='Subtask Description')
        self.tree.heading('Duration', text='Duration')
        self.tree.bind('<Double-1>', self.on_double_click)  # Edit on double-click

        ttk.Button(root, text="Add Task", command=self.add_task).grid(row=1, column=0)
        ttk.Button(root, text="Add Subtask", command=self.add_subtask_automatically).grid(row=1, column=1)
        ttk.Button(root, text="Delete Task", command=self.delete_task).grid(row=1, column=2)
        ttk.Button(root, text="Save to CSV", command=self.save_to_csv).grid(row=1, column=3)

    def on_double_click(self, event):
        """Edit directly within the Treeview."""
        item = self.tree.selection()[0]
        column = self.tree.identify_column(event.x)  # Identify the column clicked
        column_index = int(column.replace('#', '')) - 1  # Convert to integer and adjust for 0-based index
        entry_text = self.tree.item(item, 'values')[column_index]
        new_value = self.simple_edit(entry_text)
        if new_value:
            self.tree.set(item, column=column, value=new_value)

    def simple_edit(self, initial_value):
        """Prompt for new value via simple dialog."""
        return simpledialog.askstring("Input", "Update Value:", initialvalue=initial_value)

    def add_task(self):
        self.tree.insert('', 'end', values=("Enter Task Title", "Start Time", "Description", "Duration"))

    def add_subtask_automatically(self):
        children = self.tree.get_children()
        if children:
            last_item = children[-1]
            last_values = self.tree.item(last_item, 'values')
            start_time = last_values[1]
            duration = int(last_values[3])
            end_time = datetime.strptime(start_time, '%H:%M') + timedelta(minutes=duration)
            self.tree.insert('', 'end', values=(last_values[0], end_time.strftime('%H:%M'), "Enter Description", "Duration"))

    def delete_task(self):
        selected_item = self.tree.selection()
        if selected_item:
            self.tree.delete(selected_item)

    def save_to_csv(self):
        if self.tree.get_children():
            df = pd.DataFrame([self.tree.item(x)['values'] for x in self.tree.get_children()])
            df.columns = ['Task Title', 'Start Time', 'Subtask Description', 'Duration']
            df.to_csv('daily_planner_V07\planning.csv', index=False)
            messagebox.showinfo("Success", "Data saved to CSV!")
        else:
            messagebox.showinfo("Error", "No data to save.")

if __name__ == "__main__":
    root = tk.Tk()
    app = TaskManagerGUI(root)
    root.mainloop()
